# Major - Auto Claim Bot

🔗 **Referral Link**: [Major](https://t.me/major/start?startapp=5914982564)

## 📢 Telegram Group

Join our Telegram group to stay updated and get instructions on how to use this tool:

- [Smart Airdrop](https://t.me/smartairdrop2120)
- [Smart Airdrop - Channel](https://t.me/smartairdrop_channel)

## 🌟 Features

| Feature                | Status | Description                                       |
| ---------------------- | ------ | ------------------------------------------------- |
| Auto Check-in          | On/Off | Claim daily bonus to get more points              |
| Auto Do Task           | On/Off | Complete tasks                                    |
| Auto Play Hold Coin    | On/Off | Play Hold Coin to get as many points as possible  |
| Auto Spin              | On/Off | Spin to get random reward                         |
| Auto Play Swipe Coin   | On/Off | Play Swipe Coin to get as many points as possible |
| Auto Play Puzzle Durov | On/Off | Play Puzzle Durov to more points                  |

## 🚀 Run File

| Run with Proxy                   | Run without Proxy   |
| -------------------------------- | ------------------- |
| `bot-proxy.py` `data-proxy.json` | `bot.py` `data.txt` |

## ⚠️ Note

- Get auth data (`query_id=... /user=...`) in the `Application` tab in DevTools.
- Auto features: Change `false` to `true` in the `config.json` file.
- Supported commands: `/run_bot` `/query_id` `/proxy` `/proxy_web` (Join group to use these commands).
