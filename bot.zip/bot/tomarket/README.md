# Tomarket - Auto Claim Bot

Referral link: [Tomarket](https://t.me/Tomarket_ai_bot/app?startapp=000015ci)

## Telegram Group

Join our Telegram group to stay updated and get instructions on how to use this tool:

[Smart Airdrop](https://t.me/smartairdrop2120)

### Note

Get auth data (user=...) in `Network` tab in DevTools
